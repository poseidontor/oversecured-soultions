package oversecured.ovaa.objects;

import java.io.Serializable;

public class MemoryCorruptionSerializable implements Serializable {
    private static final long serialVersionUID = 0;
    private long ptr;

    public MemoryCorruptionSerializable(long ntPTR){
        ptr = ntPTR;
    }

    private native void freePtr(long j);

    static {
        System.load("/data/app/oversecured.ovaa-C-cALFQIMwPC5QzKkDwrHg==/lib/x86/libovaa.so");
    }

}