package com.example.deeplinkgranturipermission;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setClassName("oversecured.ovaa","oversecured.ovaa.activities.DeeplinkActivity");
        intent.setData(Uri.parse("oversecured://ovaa/grant_uri_permissions"));
        startActivityForResult(intent,1003);

    }
    /*
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == -1 && requestCode == 1003) {
            Log.d("Evil",String.valueOf(getIntent().getData()));
        }
    }
    */

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("test","HI there");
        if(resultCode == -1 || requestCode == 1003) {
            Uri uri = Uri.parse(String.valueOf(getIntent().getData()));
            Log.d("Evil", String.valueOf(uri));
        }
    }
}